TCPDF Library

This directory should contain the TCPDF library files.
You can download the latest version from: https://github.com/tecnickcom/TCPDF

Installation:
1. Download the TCPDF library
2. Extract the contents to this directory
3. Make sure the main TCPDF class file (tcpdf.php) is directly in this folder

For more information, visit: https://tcpdf.org/
